import 'package:dart_mavlink/dialects/common.dart';

class MavlinkData {
  static const int mySystemId = 255;
  static const int myComponentId = mavTypeGcs;

  static String currentHost = "127.0.0.1";
  static int currentPort = 14550;
  static int? targetSystemId;    
  static int? targetComponentId; 

  static bool isArdupilotReady = false;
  static bool isMavlinkConnected = false;
  static DateTime? lastPacketReceivedTime;
  static bool isArmed = false;

  static Heartbeat? lastHeartbeat;
  static SysStatus? lastSysStatus;
  static Attitude? lastAttitude;
  static VfrHud? lastVfrHud;
  static GlobalPositionInt? lastGlobalPositionInt;
  static HomePosition? lastHomePosition;


  static void reset() {
    isMavlinkConnected = false;
    lastPacketReceivedTime = null;
    isArdupilotReady = false;
    targetSystemId = null;
    targetComponentId = null;
    lastHeartbeat = null;
    lastAttitude = null;
    lastHomePosition = null;
  }
}